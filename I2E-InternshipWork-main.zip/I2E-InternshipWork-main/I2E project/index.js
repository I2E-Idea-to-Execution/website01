const login = document.querySelector(".login-btn");
login.addEventListener('click' , ()=>{
    window.open("login.html")
})